import React, { useRef, useState, useEffect } from "react";
import html2pdf from "html2pdf.js";
import EPFOLogo from "../Pdfmodal/Declaration_Form/images/EPFO_Logo.png";

import { useDispatch, useSelector } from "react-redux";

// import InputFieldNominee from "../InputNominee/InputFieldNominee_EPF";
import InputFieldNominee from '../Pdfmodal/InputNominee_EPF/InputFieldNominee';

// import { ValidateForm } from "./validationnomiee";

// import {Validate} from './validationnomiee'
// import SignatureNewModal from "../model/Signmodel";
import SignatureNewModal from "../../model/Signmodel";

// import { handleKeyPress } from "../Components/customcomponents/Validatehandlekeypress";
import { handleKeyPress } from "../customcomponents/Validatehandlekeypress";

// import { GetCandidateInfo } from "../Redux/WebFormReducer/action";
import { GetCandidateInfo } from "../../Redux/WebFormReducer/action";
import {
  GetCandidateEpfnomineee,
  PostCandidateEpfnomineee,
} from "../../Redux/UserIDReducer/action";
import {
  Attachmentsendtobackend,
  PUTndaform,
} from "../../Redux/NdaDocumentReducer/action";
import SuccessModal from "../../Components/Pdfmodal/Alertmodals/SuccessModal";
import ErrorModal from "../../Components/Pdfmodal/Alertmodals/ErrorModal";
import { CandidateStatus } from "../../Redux/EmployeeLandingReducer/action";
import { ValidateNomineeForm } from "./validationnomiee";

const EPFNomineeForm = ({ setActiveTab }) => {
  const [showSignatureModal, setShowSignatureModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [employeeSelectedDate, setEmployeeSelectedDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [errormodel, setErrormodel] = useState(null);
  const [sucessmodel, setsucessmodal] = useState(null);
  const [Isgeneratingpdf, setIsgeneratingpdf] = useState(false);
  const [employeeSignatureData, setEmployeeSignatureData] = useState("");
  const [signatureData, setSignatureData] = useState(null);
  const [signatureType, setSignatureType] = useState("");
  const dispatch = useDispatch();

  const loggeddata = JSON.parse(localStorage.getItem("userlogged"));
  const Candidateinfo = useSelector(
    (state) => state.WebFormReducer.Candidateinfo
  );
  const candidateStatus = useSelector(
    (state) => state.EmployeeLandingReducer.CandidateStatus
  );

  useEffect(() => {
    const loggeddata = JSON.parse(localStorage.getItem("userlogged"));
    dispatch(CandidateStatus(loggeddata[0]?.EmailId));
  }, []);

  // console.log(candidateStatus,'status==============')

  const nomineepfinfo = useSelector(
    (state) => state.UserIDReducer.EPFnomineedata
  );

  const userEmailid = loggeddata[0]?.EmailId;
  // const userEmailid = ''

  useEffect(() => {
    dispatch(GetCandidateInfo(userEmailid));
  }, [userEmailid]);

  // console.log("nomineepfinfo", nomineepfinfo);

  useEffect(() => {
    if (Candidateinfo.length > 0) {
      dispatch(GetCandidateEpfnomineee(Candidateinfo[0]?.EmpID));
    }
  }, [Candidateinfo]);

  function convertDateFormatyyyymmdd(dateString) {
    const [day, month, year] = dateString.split("/");

    const dateObject = new Date(`${year}-${month}-${day}`);

    const newYear = dateObject.getFullYear();
    const newMonth = String(dateObject.getMonth() + 1).padStart(2, "0");
    const newDay = String(dateObject.getDate()).padStart(2, "0");

    return `${newYear}-${newMonth}-${newDay}`;
  }

  useEffect(() => {
    if (nomineepfinfo?.Response === "No records found") {
      setBasicData((prevState) => ({
        ...prevState,
        firstName: "",
        middleName: "",
        lastName: "",
        dateOfBirth: "",
        accountNo: "",
        gender: "",
        maritalStatus: "",
        address: "",
      }));

      setNominees((prevState) =>
        prevState.map((nominee, index) => {
          if (index === 0) {
            return {
              ...nominee,
              name: "",
              address: "",
              relationship: "",
              dob: "",
              amount: "",
              guardian: "",
            };
          }
          return nominee;
        })
      );

      setFamilyMembers((prevState) =>
        prevState.map((nominee, index) => {
          if (index === 0) {
            return {
              ...nominee,
              nameAddress: "",
              age: "",
              relationship: "",
            };
          }
          return nominee;
        })
      );

      setFamilyMembers2((prevState) =>
        prevState.map((nominee, index) => {
          if (index === 0) {
            return {
              ...nominee,
              nameAddress: "",
              dob: "",
              relationship: "",
            };
          }
          return nominee;
        })
      );
    } else {
      if (Object.keys(nomineepfinfo).length > 0) {
        setEmployeeSelectedDate(nomineepfinfo?.Table[0]?.EmpDate);
        setBasicData((prevState) => ({
          ...prevState,
          firstName: nomineepfinfo?.Table[0]?.EmpName,
          middleName: nomineepfinfo?.Table[0]?.FatherOrHusbandName,
          lastName: nomineepfinfo?.Table[0]?.Surname,
          dateOfBirth: convertDateFormatyyyymmdd(nomineepfinfo?.Table[0]?.DOB),
          accountNo: nomineepfinfo?.Table[0]?.AccountNo,
          gender: nomineepfinfo?.Table[0]?.Gender,
          maritalStatus: nomineepfinfo?.Table[0]?.MaritalStatus,
          address: nomineepfinfo?.Table[0]?.Address,
        }));

        // Update nominees array
        // setNominees((prevState) =>
        //   prevState.map((nominee, index) => {
        //     if (index === 0) {
        //       return {
        //         ...nominee,
        //         name: nomineepfinfo?.Table1[0]?.NomineeName,
        //         address: nomineepfinfo?.Table1[0]?.Address,
        //         relationship: nomineepfinfo?.Table1[0]?.RelationshipWithMember,
        //         dob: nomineepfinfo?.Table1[0]?.DOB,
        //         amount: nomineepfinfo?.Table1[0]?.TotalAmountOrShare,
        //         guardian: nomineepfinfo?.Table1[0]?.GuardianDetail,
        //       };
        //     }
        //     return nominee;
        //   })
        // );

        // Update nominees array

        // setNominees((prevState) =>
        //   prevState.map((nominee, index) => {
        //     if (index === 0) {
        //       return {
        //         ...nominee,
        //         name: nomineepfinfo?.Table1[0]?.NomineeName,
        //         address: nomineepfinfo?.Table1[0]?.Address,
        //         relationship: nomineepfinfo?.Table1[0]?.RelationshipWithMember,
        //         dob: nomineepfinfo?.Table1[0]?.DOB,
        //         amount: nomineepfinfo?.Table1[0]?.TotalAmountOrShare,
        //         guardian: nomineepfinfo?.Table1[0]?.GuardianDetail,
        //       };
        //     }
        //     return nominee;
        //   })
        // );


        // updating all the nominee entries
        setNominees((prevState) =>
          prevState.map((nominee, index) => {
            if (index === 0 || index === 1 || index === 2 || index === 3) {
              return {
                ...nominee,
                name: nomineepfinfo?.Table1[index]?.NomineeName,
                address: nomineepfinfo?.Table1[index]?.Address,
                relationship: nomineepfinfo?.Table1[index]?.RelationshipWithMember,
                dob: nomineepfinfo?.Table1[index]?.DOB,
                amount: nomineepfinfo?.Table1[index]?.TotalAmountOrShare,
                guardian: nomineepfinfo?.Table1[index]?.GuardianDetail,
              };
            }
            return nominee;
          })
        );




        setFamilyMembers((prevState) =>
          prevState.map((nominee, index) => {
            if (index === 0) {
              return {
                ...nominee,
                nameAddress: nomineepfinfo?.Table2[0]?.FamilyMemberDetails,
                age: nomineepfinfo?.Table2[0]?.Age,
                relationship: nomineepfinfo?.Table2[0]?.RelationshipWithMember,
              };
            }
            return nominee;
          })
        );

        setFamilyMembers2((prevState) =>
          prevState.map((nominee, index) => {
            if (index === 0) {
              return {
                ...nominee,
                nameAddress: nomineepfinfo?.Table3[0]?.NomineeDetails,
                dob: convertDateFormatyyyymmdd(nomineepfinfo?.Table3[0]?.DOB),
                relationship: nomineepfinfo?.Table3[0]?.RelationshipWithMember,
              };
            }
            return nominee;
          })
        );
      }
    }
  }, [nomineepfinfo]);

  const closeSignatureModal = () => {
    setShowSignatureModal(false);
  };
  //   first Basic details

  console.log(employeeSignatureData, "==========sign data========");

  const openSignatureModal = (role) => {
    setShowSignatureModal(true);
    // Set the appropriate state variable based on the role
    switch (role) {
      case "employee":
        setSignatureType("employee");
        break;
      // case "employer":
      //   setSignatureType("employer");
      //   break;
      default:
        break;
    }
  };

  const handleSaveSignature = (data) => {
    // Update the appropriate state variable based on the saved signature
    console.log("Signature Data:", data);
    switch (signatureType) {
      case "employee":
        setEmployeeSignatureData(data.data);
        break;
      // case "employer":
      //   setEmployerSignatureData(data.data);
      //   break;
      default:
        break;
    }
    closeSignatureModal();
  };

  const [basicData, setBasicData] = useState({
    firstName: "",
    middleName: "",
    lastName: "",
    dateOfBirth: new Date().toISOString().split("T")[0],
    accountNo: "",
    gender: "",
    maritalStatus: "",
    address: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (value.startsWith(" ")) {
      return;
    }
    setBasicData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handlefirstNameChange = (e) => {
    const { name, value } = e.target;

    setBasicData({
      ...basicData,
      [name]: value,
    });
  };

  const handleclosesucessmodal = () => {
    setsucessmodal(null);
    setActiveTab("applicant segment");
  };

  const handlecloseerrormodal = () => {
    setErrormodel(null);
  };
  // console.log(basicData);

  //  EPS DEtails

  const [nominees, setNominees] = useState(
    Array.from({ length: 6 }, () => ({
      name: "",
      address: "",
      relationship: "",
      dob: "",
      amount: "",
      guardian: "",
    }))
  );

  const handleNomineeChange = (rowIndex, colIndex, value) => {
    const newNominees = [...nominees];

    newNominees[rowIndex][colIndex] = value;
  };
  //  console.log("nomieeeeww==========", nominees)

  //  Family details and EPF

  const [familyMembers, setFamilyMembers] = useState(
    Array.from({ length: 3 }, () => ({
      nameAddress: "",
      age: "",
      relationship: "",
    }))
  );

  const handleFamilyMemberChange = (index, col, value) => {
    const newFamilyMembers = [...familyMembers];
    newFamilyMembers[index][col] = value;
  };

  //  console.log("familyMembers=============",familyMembers)

  //  Family members two

  const [familyMembers2, setFamilyMembers2] = useState([
    {
      nameAddress: "",
      dob: "",
      relationship: "",
    },
    // Add two more initial members if needed
    {
      nameAddress: "",
      dob: "",
      relationship: "",
    },
    {
      nameAddress: "",
      dob: "",
      relationship: "",
    },
  ]);

  const handleFamilyMemberChange2 = (index, col, value) => {
    const newFamilyMembers2 = [...familyMembers2];
    newFamilyMembers2[index][col] = value;
  };

  // console.log("basicdataaa===========",basicData)

  // console.log("familyMembers2==============", familyMembers2);

  //  sign part

  // console.log("employeeSelectedDate", employeeSelectedDate);
  function convertDateFormat(inputDate) {
    // Check if inputDate is null or undefined
    if (inputDate === null || inputDate === undefined) {
      return null;
    }

    // Split the input date string by '/'
    const parts = inputDate.split("/");

    // Check if the input date has three parts (day, month, year)
    if (parts.length === 3) {
      // Extract day, month, and year
      const day = parts[0];
      const month = parts[1];
      const year = parts[2];

      // Create a new date string in the "yyyy/mm/dd" format
      const newDateString = `${year}-${month.padStart(2, "0")}-${day.padStart(
        2,
        "0"
      )}`;

      return newDateString;
    } else {
      // If the input date format is invalid, return null
      return null;
    }
  }

  // mapping array for mulitple nominees sendingto backedn

  const nomineeEPF = nominees.map((nominee) => ({
    NomineeName: nominee.name,
    NomineeAddress: nominee.address,
    NomineeRelationship: nominee.relationship,
    NomineeDOB: convertDateFormat(nominee.dob), // Assuming convertDateFormat converts date format
    NomineeTotalShare: nominee.amount,
    NameAndAddrOfGuardian: nominee.guardian,
  }));

  const sendPdfToBackend = (formData) => {
    const nomineePostResponse = {
      ObjPFNomineeForm: {
        EmpID: Candidateinfo[0]?.EmpID,
        EmpName: basicData.firstName,
        FatherOrHusbandName: basicData.middleName,
        Surname: basicData.lastName,
        DOB: basicData.dateOfBirth,
        AccountNo: basicData.accountNo,
        Gender: basicData.gender,
        MaritalStatus: basicData.maritalStatus,
        Address: basicData.address,
        EmpDate: convertDateFormatyyyymmdd(employeeSelectedDate),
        EmployerName: "",
        EmployerDate: "",
        EmployerNameAndAddress: "",
        EmployerPlace: "",
        EmployerDate1: "",
        CreatedBy: loggeddata[0]?.EmailId,
      },
      // NomineeEPF: [
      //   {
      //     NomineeName: nominees[0]?.name,
      //     NomineeAddress: nominees[0]?.address,
      //     NomineeRelationship: nominees[0]?.relationship,
      //     NomineeDOB: convertDateFormat(nominees[0]?.dob),
      //     NomineeTotalShare: nominees[0]?.amount,
      //     NameAndAddrOfGuardian: nominees[0]?.guardian,
      //   },
      // ],
      NomineeEPF: nomineeEPF,
      NomineeEPS: [
        {
          EPSSNo: "1",
          NameAndAddrOfFamily: familyMembers[0]?.nameAddress,
          Age: familyMembers[0]?.age,
          RealtionshipWithMember: familyMembers[0]?.relationship,
        },
      ],
      NomineeWP: [
        {
          NameAndAddrOfNominee: familyMembers2[0]?.nameAddress,
          WpDOB: familyMembers2[0]?.dob,
          WpRealtionshipWithMember: familyMembers2[0]?.relationship,
        },
      ],
    };
    const nomineePutResponse = {
      ObjPFNomineeForm: {
        EmpID: Candidateinfo[0]?.EmpID,
        EmpName: basicData.firstName,
        FatherOrHusbandName: basicData.middleName,
        Surname: basicData.lastName,
        DOB: basicData.dateOfBirth,
        AccountNo: basicData.accountNo,
        Gender: basicData.gender,
        MaritalStatus: basicData.maritalStatus,
        Address: basicData.address,
        EmpDate: convertDateFormatyyyymmdd(employeeSelectedDate),
        EmployerName: "",
        EmployerDate: "",
        EmployerNameAndAddress: "",
        EmployerPlace: "",
        EmployerDate1: "",
        UserType: "Candidate",
        UpdatedBy: loggeddata[0]?.EmailId,
      },
      // NomineeEPF: [
      //   {
      //     NomineeName: nominees[0]?.name,
      //     NomineeAddress: nominees[0]?.address,
      //     NomineeRelationship: nominees[0]?.relationship,
      //     NomineeDOB: convertDateFormat(nominees[0]?.dob),
      //     NomineeTotalShare: nominees[0]?.amount,
      //     NameAndAddrOfGuardian: nominees[0]?.guardian,
      //   },
      // ],
      NomineeEPF: nomineeEPF,
      NomineeEPS: [
        {
          EPSSNo: "1",
          NameAndAddrOfFamily: familyMembers[0]?.nameAddress,
          Age: familyMembers[0]?.age,
          RealtionshipWithMember: familyMembers[0]?.relationship,
        },
      ],
      NomineeWP: [
        {
          NameAndAddrOfNominee: familyMembers2[0]?.nameAddress,
          WpDOB: familyMembers2[0]?.dob,
          WpRealtionshipWithMember: familyMembers2[0]?.relationship,
        },
      ],
    };

    console.log("payload dataa===============", nomineePutResponse);
    console.log(employeeSignatureData, "emp sign=============");

    dispatch(Attachmentsendtobackend(Candidateinfo[0]?.EmpID, formData))
      .then((res) => {
        console.log("rees", res);
        console.log("PDF sent successfully.");
        setIsgeneratingpdf(false);

        console.log("payload dataa===============", nomineePutResponse);
        setSignatureData(
          `https://globalsync.acnhealthcare.com/GetIntegrationAPI/api/file/SignatureFile/${"signature_NomineeForm.png"}/${
            Candidateinfo[0]?.EmpID
          }/`
        );

        if (res?.payload?.data === "Files uploaded successfully.") {
          if (nomineepfinfo?.Response === "No records found") {
            const params = `PFNomineeForm/SubmitPFNomineeForm/`;
            dispatch(PostCandidateEpfnomineee(params, nomineePostResponse))
              .then((res) => {
                console.log("res from post===============", res);
                if (
                  res.payload[0]?.Column1 === "Details Submitted Successfully"
                ) {
                  setsucessmodal("PDF saved succesfully!!!");
                }
              })
              .catch((err) => {
                console.log("err", err);
              });
          } else {
            const param = `PFNomineeForm/UpdatePFNomineeForm/${loggeddata[0]?.EmailId}/`;
            dispatch(PUTndaform(param, nomineePutResponse))
              .then((res) => {
                console.log("res", res);
                if (res.payload.data) {
                  setsucessmodal("PDF saved succesfully!!!");
                }
              })
              .catch((err) => {
                console.log("err", err);
              });
          }
        }
      })
      .catch((err) => {
        console.log("err", err);
      });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    setLoading(true);

    const formData = { ...basicData };

    const trimmedFormData = Object.fromEntries(
      Object.entries(formData).map(([key, value]) => [
        key,
        typeof value === "string" ? value.trim() : value,
      ])
    );

    //  here validations done
    const formDataValidationErrors = ValidateNomineeForm(trimmedFormData);
    setErrors(formDataValidationErrors);
    //  you can check here whihch innput filed are empty also

    console.log("formvalidatiosn==============", formDataValidationErrors);

    const hasErrors = Object.keys(formDataValidationErrors).length > 0;

    console.log("hasErrors==============", hasErrors);
    // if no error  then only api hit

    if (!hasErrors) {
      setLoading(false);
      setIsgeneratingpdf(true);

         if(candidateStatus.PFNomineeForm !== "completed" ){
          if (employeeSignatureData === "") {
            setErrormodel("Please Sign the Document before saving the PDF.");
            return;
          }
         }
     
      const input = document.getElementById("pdf-content");
      if (!input) {
        console.error("Element with id 'pdf-content' not found.");
        return;
      }

      const convertImagesToBase64 = async () => {
        const images = input.getElementsByTagName("img");
        for (const img of images) {
          if (img.src.startsWith("http")) {
            await fetch(img.src)
              .then((response) => response.blob())
              .then((blob) => {
                return new Promise((resolve) => {
                  const reader = new FileReader();
                  reader.onloadend = () => {
                    img.src = reader.result;
                    resolve();
                  };
                  reader.readAsDataURL(blob);
                });
              })
              .catch((error) =>
                console.error("Error converting image to base64:", error)
              );
          }
        }
      };
      convertImagesToBase64().then(() => {
        html2pdf()
        .from(input)
        .set({
          margin: [2, 2],
          filename: "NomineeForm.pdf",
          html2canvas: { scale: 1 },
          jsPDF: { unit: "mm", format: "a3", orientation: "portrait" },
          pagebreak: { before: ".page-break" },
        })
        .save()
        .outputPdf("blob")
        .then((blob) => {
          const formData = new FormData();
          formData.append("file", blob, "NomineeForm.pdf");

            if(employeeSignatureData !== ""){
              const signatureBlob = base64ToBlob(
                employeeSignatureData,
                "image/png"
              );
              formData.append(
                "signature",
                signatureBlob,
                "signature_NomineeForm.png"
              );
            }
        
          sendPdfToBackend(formData);
        })
        .catch((error) => {
          console.error("Error generating PDF:", error);
        });
      })


   
      return;
    }

    if (hasErrors) {
      const errorField = Object.keys(formDataValidationErrors)[0];
      const fieldElement = document.querySelector(`[name="${errorField}"]`);
      if (fieldElement) {
        fieldElement.focus();
      }
    }
  };

  const base64ToBlob = (base64, mime) => {
    const byteCharacters = atob(base64.split(",")[1]);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mime });
  };

  return (
    <>
      <div className="w-[1149px] m-auto">
        <div   >
          <form onSubmit={handleSubmit}>

            <div id="pdf-content">

            <div className="px-2 py-1 border-black bg-[#fffff]" >
              <div
                className="sedan-sc-regular border-black text-left leading-1 tracking-wide py-4 mx-auto w-[100%]  
                gap-4 px-2 rounded"
              >
                <h2 className="px-4 text-end font-semibold">
                  (FORM 2 REVISED){" "}
                </h2>
                <div className="px-4 border-green-700 py-2">
                  <h1 className="text-[17px] font-bold text-center">
                    NOMINATION AND DECLARATION FORM FOR UNEXEMPTED/EXEMPTED
                    ESTABLISHMENTS
                  </h1>
                  <h1 className="text-[15px] py-1 font-normal text-center">
                    Declaration and Nomination Form under the Employees
                    Provident Funds and Employees Pension Schemes
                  </h1>
                  <h1 className="text-[15px] font-normal text-center">
                    (Paragraph 33 and 61 (1) of the Employees Provident Fund
                    Scheme 1952 and Paragraph 18 of the Employees Pension Scheme
                    1995)
                  </h1>
                </div>

                <div className="flex" style={{ marginTop: "50px" }}>
                  <div className="flex ">
                    <div>1. Name (IN BLOCK LETTERS) :</div>
                    <div
                      style={{
                        width: "265px",
                        textAlign: "center",
                        paddingRight: "5px",
                      }}
                    >
                      {Isgeneratingpdf ? (
                        <span
                          className={`border-b-[1px] py-2 px-20 w-[265px] border-gray-300 `}
                        >
                          {basicData.firstName}
                        </span>
                      ) : (
                        <InputFieldNominee
                          type="text"
                          name="firstName"
                          value={basicData.firstName}
                          onChange={handlefirstNameChange}
                          autoFocus
                          className={`border-b-[1px] uppercase border-gray-300 w-full`}
                          error={submitted && errors.firstName}
                          onKeyPress={(e) => handleKeyPress(e, "text", 50)}
                        />
                      )}
                    </div>
                    <div
                      style={{
                        width: "265px",
                        textAlign: "center",
                        paddingRight: "5px",
                      }}
                    >
                      <span>
                        {Isgeneratingpdf ? (
                          <span
                            className={`border-b-[1px] py-2 px-20 border-gray-300 w-full`}
                          >
                            {basicData.middleName}
                          </span>
                        ) : (
                          <InputFieldNominee
                            type="text"
                            name="middleName"
                            value={basicData.middleName}
                            onChange={handlefirstNameChange}
                            className="border-b-[1px] border-gray-300 w-full"
                            error={submitted && errors.middleName}
                            onKeyPress={(e) => handleKeyPress(e, "text", 50)}
                          />
                        )}
                        <br />
                        <br />
                        Father’s / Husband’s Name
                      </span>
                    </div>
                    <div style={{ textAlign: "center", paddingRight: "5px" }}>
                      <span>
                        {Isgeneratingpdf ? (
                          <span
                            className={`border-b-[1px] py-2 px-20 border-gray-300 w-full`}
                          >
                            {basicData.lastName}
                          </span>
                        ) : (
                          <InputFieldNominee
                            type="text"
                            name="lastName"
                            value={basicData.lastName}
                            onChange={handlefirstNameChange}
                            className="border-b-[1px] border-gray-300 w-full"
                            error={submitted && errors.lastName}
                            onKeyPress={(e) => handleKeyPress(e, "text", 50)}
                          />
                        )}
                        <br />
                        <br />
                        Surname
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex" style={{ marginTop: "10px" }}>
                  <div className="flex">
                    <div>2. Date of Birth : </div>
                    <div style={{ paddingRight: "15px" }}>
                      {Isgeneratingpdf ? (
                        <span
                          className={`border-b-[1px] py-2 px-20 border-gray-300 w-full`}
                        >
                          {basicData.dateOfBirth}
                        </span>
                      ) : (
                        <InputFieldNominee
                          type="date"
                          name="dateOfBirth"
                          value={basicData.dateOfBirth}
                          onChange={handleInputChange}
                          className={`border-b-[1px] border-gray-300 w-full ${
                            basicData.dateOfBirth === "" ? "border-red-500" : ""
                          }`}
                          error={submitted && errors.dateOfBirth}
                        />
                      )}
                    </div>
                    <div>3. Account No.</div>
                    <div className="w-[350px]">
                      {Isgeneratingpdf ? (
                        <span
                          className={`border-b-[1px] py-2 px-20 border-gray-300 w-full`}
                        >
                          {basicData.accountNo}
                        </span>
                      ) : (
                        <InputFieldNominee
                          type="text"
                          name="accountNo"
                          value={basicData.accountNo}
                          onChange={handleInputChange}
                          className="border-b-[1px] border-gray-300 w-full"
                          error={submitted && errors.accountNo}
                          onKeyPress={(e) =>
                            handleKeyPress(e, "alphanumeric", 50)
                          }
                        />
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex" style={{ marginTop: "18px" }}>
                  <div className="flex">
                    <div>4. *Sex : MALE/FEMALE:</div>
                    <div style={{ paddingRight: "15px" }}>
                      {Isgeneratingpdf ? (
                        <span
                          className={`border-b-[1px] py-2 px-20 border-gray-300 w-full`}
                        >
                          {basicData.gender}
                        </span>
                      ) : (
                        <InputFieldNominee
                          type="select"
                          name="gender"
                          value={basicData.gender}
                          onChange={handleInputChange}
                          options={["Male", "Female", "Other"]}
                          error={submitted && errors.gender}
                        />
                      )}
                    </div>
                    <div>5. Marital Status</div>
                    <div>
                      {Isgeneratingpdf ? (
                        <span
                          className={`border-b-[1px] py-2 px-20 border-gray-300 w-full`}
                        >
                          {basicData.maritalStatus}
                        </span>
                      ) : (
                        <InputFieldNominee
                          type="select"
                          name="maritalStatus"
                          value={basicData.maritalStatus}
                          onChange={handleInputChange}
                          options={[
                            "Married",
                            "UnMarried",
                            "Single",
                            "Divorcee",
                          ]}
                          error={submitted && errors.maritalStatus}
                        />
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex" style={{ marginTop: "18px" }}>
                  <div className="flex">
                    <div>6. Address Permanent / Temporary :</div>
                    <div style={{ width: "700px" }}>
                      {Isgeneratingpdf ? (
                        <span
                          className={`border-b-[1px] py-2 px-20 border-gray-300 w-full`}
                        >
                          {basicData.address}
                        </span>
                      ) : (
                        <InputFieldNominee
                          type="textarea"
                          name="address"
                          value={basicData.address}
                          onChange={handleInputChange}
                          className="p-2 w-full border-b-[1px] border-gray-300"
                          error={submitted && errors.address}
                          onKeyPress={(e) => handleKeyPress(e, "none", 100)}
                        />
                      )}
                    </div>
                  </div>
                </div>

                {/* Sign  */}
              </div>

              {/*  Table nomioneee started form here  */}

              {/*  */}
              <div className="px-4 border-green-700 py-2">
                <h1 className="text-xl  font-bold mb-6 text-center">
                  PART-A (EPF)
                </h1>
                <h1 className="text-sm  font-normal text-start">
                  hereby nominate the person(s)/cancel the nomination made by me
                  previously and nominate the person(s) mentioned below to
                  receive the amount standing to my credit in the Employees
                  Provident Fund, in the event of my death
                </h1>

                <div className=" px-4 py-2"></div>

                {/*  second point */}

                {/* ====================================  */}
              </div>

              <div className="mx-auto rounded px-2 pb-8 mb-4">
                <table className="clsbordercollapse clstbl">
                  <thead>
                    <tr>
                      <th className="border font-semibold text-xs text-center border-gray-300 p-2">
                        Name of the Nominee(s)
                      </th>
                      <th className="border font-semibold text-xs text-center border-gray-300 p-2">
                        Address
                      </th>
                      <th className="border font-semibold text-xs text-center border-gray-300 p-2">
                        Nominee’s relationship with the member
                      </th>
                      <th className="border font-semibold text-xs text-center border-gray-300 p-2">
                        Date of Birth
                      </th>
                      <th className="border font-semibold text-xs text-center border-gray-300 p-2">
                        Total amount or share of accumulations in Provident
                        Funds to be paid to each nominee
                      </th>
                      <th className="border font-semibold text-xs text-center border-gray-300 p-2">
                        If the nominee is minor, name and address of the
                        guardian who may receive the amount during the minority
                        of the nominee
                      </th>
                    </tr>
                  </thead>

                  <tbody>
                    <tr>
                      <td align="center">1</td>
                      <td align="center">2</td>
                      <td align="center">3</td>
                      <td align="center">4</td>
                      <td align="center">5</td>
                      <td align="center">6</td>
                    </tr>

                    {nominees.map((row, rowIndex) => (
                      <tr key={rowIndex}>
                        {Object?.keys(row)?.map((col, colIndex) => (
                          <td
                            key={colIndex}
                            className="border text-left border-gray-300 p-1 h-[100px] w-[90px]"
                          >
                            <div
                              contentEditable={true}
                              suppressContentEditableWarning={true}
                              name={`${rowIndex}-${colIndex}`} // Unique name for each cell
                              onInput={(e) =>
                                handleNomineeChange(
                                  rowIndex,
                                  col,
                                  e.target.textContent
                                )
                              }
                              maxLength={50}
                              style={{
                                width: "169px",
                                height: "100px",
                                overflowWrap: "break-word",
                                whiteSpace: "pre-wrap",
                                overflow: "hidden",
                                textAlign: "left",
                              }}
                              autoFocus={true}
                              className=" border rounded w-full text-gray-700 py-2 px-2 "
                            >
                              {row[col]}
                            </div>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* table Nomieee End*/}

              <div className=" px-4 flex  gap-5 border-green-700 py-2">
                <span>1</span>

                <h1 className="text-sm  font-normal text-start">
                  *Certified that I have no family as defined in para 2 (g) of
                  the Employees Provident Fund Scheme 1952 and should I acquire
                  a family hereafter the above nomination should be deemed as
                  cancelled.{" "}
                </h1>
              </div>

              <div className=" px-4 flex  gap-5 border-green-700 py-2">
                <span>2</span>

                <h1 className="text-sm  font-normal text-start">
                  * Certified that my father/mother is/are dependent upon me.{" "}
                </h1>
              </div>

              {/* ====================================  */}
              <div className="px-4 flex justify-between gap-5 border-green-700 py-4">
                <h2>Strike out whichever is not applicable </h2>

                <h2 className="text-sm  text-start">
                  <td
                    // onClick={() => openSignatureModal("employee")}
                    className="sign px-2 py-1"
                  >
                    <div
                      onClick={() => openSignatureModal("employee")}
                      className="sign px-2 py-1"
                    >
                      {/* PFNomineeForm */}

                      {/* {employeeSignatureData ? (
                        <>
                          <img
                            src={employeeSignatureData}
                            alt="signature"
                            style={{ height: "80px" }}
                          />
                          <p>SIGNATURE OF MEMBER</p>
                        </>
                      ) : (
                        "SIGNATURE OF MEMBER"
                      )} */}

                      {candidateStatus.PFNomineeForm === "completed" ? (
                        employeeSignatureData ? (
                          <td
                            onClick={() => openSignatureModal("employee")}
                            className="sign px-4 py-1 h-[90px]"
                          >
                            <img
                              src={employeeSignatureData}
                              alt="signature"
                              style={{ width: "80px", height: "60px" }}
                            />
                            <p>SIGNATURE OF MEMBER</p>
                          </td>
                        ) : (
                          <td
                            onClick={() => openSignatureModal("employee")}
                            className="sign px-4 py-1 h-[90px]"
                          >
                            <img
                              src={`https://globalsync.acnhealthcare.com/GetIntegrationAPI/api/file/SignatureFile/signature_NomineeForm.png/${Candidateinfo[0]?.EmpID}/`}
                              alt="signature"
                              style={{ width: "80px", height: "50px" }}
                            />
                            <p>SIGNATURE OF MEMBER</p>
                          </td>
                        )
                      ) : (
                        <td
                          onClick={() => openSignatureModal("employee")}
                          className="sign px-4 py-1 h-[90px]"
                        >
                          {employeeSignatureData ? (
                            employeeSignatureData ? (
                              <>
                                <img
                                  src={employeeSignatureData}
                                  alt="signature"
                                  style={{ width: "80px", height: "60px" }}
                                />
                                <p>SIGNATURE OF MEMBER</p>
                              </>
                            ) : (
                              <span className="sign px-2 py-1">{TextData}</span>
                            )
                          ) : (
                            "Click to Sign"
                          )}
                        </td>
                      )}
                    </div>

                    {/* <span className="sign px-2 py-1">
                        Signature/or thumb impression of the subscriber to Sign
                      </span> */}
                  </td>
                </h2>
              </div>

              <div className="px-4 border-green-700 py-2">
                <h1 className="text-xl  font-bold mb-6 text-center">
                  PART- (EPS)
                </h1>
                <h1 className="text-sm  font-bold mb-6 text-center">Para 18</h1>

                <h1 className="text-sm  font-semibold text-start">
                  I here by furnish below particulars of the members of my
                  family who would be eligible to receive Widow/Children Pension
                  in the event of my premature death in service.
                </h1>
              </div>
            </div>

            {/*  family members  */}

            <div className="mx-auto rounded px-2 pb-8 mb-4">
              <table className="clsbordercollapse clstbl">
                <thead>
                  <tr>
                    <th width="100">Sr. No</th>

                    <th className="border font-semibold text-center border-gray-300 p-2">
                      Name & Address of The Family Member
                    </th>
                    <th className="border font-semibold text-center border-gray-300 p-2">
                      Age
                    </th>
                    <th className="border font-semibold text-center border-gray-300 p-2">
                      Relationship with member
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td align="center">(1)</td>
                    <td align="center">(2)</td>
                    <td align="center">(3)</td>
                    <td align="center">(4)</td>
                  </tr>

                  {familyMembers.map((member, index) => (
                    <tr key={index}>
                      <td align="center">{index + 1}</td>

                      {Object.keys(member).map((col, subIndex) => (
                        <td
                          key={subIndex}
                          className="border text-left border-gray-300 p-1 h-[100px] w-[50px]"
                        >
                          <div
                            contentEditable={true}
                            suppressContentEditableWarning={true}
                            name={`${index}-${subIndex}`} // Unique name for each cell
                            onInput={(e) =>
                              handleFamilyMemberChange(
                                index,
                                col,
                                e.target.textContent
                              )
                            }
                            maxLength={50}
                            style={{
                              width: "325px",
                              height: "100px",
                              overflowWrap: "break-word",
                              whiteSpace: "pre-wrap",
                              overflow: "hidden",
                              textAlign: "left",
                            }}
                            autoFocus={true}
                           className=" border rounded w-full text-gray-700 py-2 px-2 "
                          >
                            {member[col]}
                          </div>
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/*  family members ends here */}

            {/*  started Family members two started */}

            <div className="px-4 border-green-700 py-2">
              <h1 className="text-sm py-2 font-semibold text-start">
                Certified that I have no family as defined in para 2 (vii) of
                the Employees’s Family Pension Scheme 1995 and should I acquire
                a family hereafter I shall furnish Particulars there on in the
                above form.
              </h1>

              <h1 className="text-sm py-2 font-semibold text-start">
                I hereby nominate the following person for receiving the monthly
                widow pension (admissible under para 16 2 (a) (i) & (ii) in the
                event of my death without leaving any eligible family member for
                receiving pension.
              </h1>
            </div>

            <div className="mx-auto rounded px-2 pb-8 mb-4">
              <table className="clsbordercollapse clstbl w-full">
                <thead>
                  <tr>
                    <th className="border font-semibold text-center border-gray-300 p-2">
                      Name & Address of The Family Member
                    </th>
                    <th className="border font-semibold text-center border-gray-300 p-2">
                      Date of Birth
                    </th>
                    <th className="border font-semibold text-center border-gray-300 p-2">
                      Relationship with member
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {familyMembers2.map((member, index) => (
                    <tr key={index}>
                      {Object.keys(member).map((col, subIndex) => (
                        <td
                          key={subIndex}
                          className="border text-left border-gray-300 p-1"
                        >
                          {col === "dob" ? (
                            <InputFieldNominee
                              type={"date"}
                              name={"dob"}
                              onChange={(e) => {
                                const newDate = e.target.value;
                                const updatedMembers = [...familyMembers2];
                                updatedMembers[index].dob = newDate;
                                setFamilyMembers2(updatedMembers);
                              }}
                              value={member.dob}
                              className="w-full text-gray-700 leading-tight  focus:border-blue-500 py-2 px-2"
                            />
                          ) : (
                            <div
                              contentEditable={true}
                              suppressContentEditableWarning={true}
                              name={`${index}-${subIndex}`} // Unique name for each cell
                              onInput={(e) =>
                                handleFamilyMemberChange2(
                                  index,
                                  col,
                                  e.target.textContent
                                )
                              }
                              maxLength={50}
                              style={{
                                width: "100%",
                                height: "100px",
                                overflowWrap: "break-word",
                                whiteSpace: "pre-wrap",
                                overflow: "hidden",
                                textAlign: "left",
                              }}
                              autoFocus={true}
                            className=" border rounded w-full text-gray-700 py-2 px-2 "
                            >
                              {member[col]}
                            </div>
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="px-4 flex justify-between gap-5 border-green-700 py-4">
              <div className="flex gap-2">
                <h2 className="py-2"> Date </h2>
                <InputFieldNominee
                  type={"date"}
                  name={"dob"}
                  onChange={(e) => setEmployeeSelectedDate(e.target.value)}
                  value={employeeSelectedDate}
                  className="w-full text-gray-700 leading-tight  focus:border-blue-500 py-2 px-2"
                />
              </div>

              <h2>{/* Date: ________________  */}</h2>

              <h2 className="text-sm mt-10 font-normal text-start">
                <td
                  onClick={() => openSignatureModal("employee")}
                  className="sign px-2 py-1"
                >
             
                    <span>
                       {candidateStatus.PFNomineeForm === "completed" ? (
                        employeeSignatureData ? (
                          <td
                            onClick={() => openSignatureModal("employee")}
                            className="sign px-4 py-1 h-[90px]"
                          >
                            <img
                              src={employeeSignatureData}
                              alt="signature"
                              style={{ width: "80px", height: "60px" }}
                            />
                            <p>SIGNATURE OF MEMBER</p>
                          </td>
                        ) : (
                          <td
                            onClick={() => openSignatureModal("employee")}
                            className="sign px-4 py-1 h-[90px]"
                          >
                            <img
                              src={`https://globalsync.acnhealthcare.com/GetIntegrationAPI/api/file/SignatureFile/signature_NomineeForm.png/${Candidateinfo[0]?.EmpID}/`}
                              alt="signature"
                              style={{ width: "80px", height: "50px" }}
                            />
                            <p>SIGNATURE OF MEMBER</p>
                          </td>
                        )
                      ) : (
                        <td
                          onClick={() => openSignatureModal("employee")}
                          className="sign px-4 py-1 h-[90px]"
                        >
                          {employeeSignatureData ? (
                            employeeSignatureData ? (
                              <>
                                <img
                                  src={employeeSignatureData}
                                  alt="signature"
                                  style={{ width: "80px", height: "60px" }}
                                />
                                <p>SIGNATURE OF MEMBER</p>
                              </>
                            ) : (
                              <span className="sign px-2 py-1">{TextData}</span>
                            )
                          ) : (
                            "Click to Sign"
                          )}
                        </td>
                      )}
                      <span className="sign px-2 py-1">
                        Signature/or thumb impression of the subscriber to Sign
                      </span>
                    </span>
                
                    {/* <span className="sign px-2 py-1">
                      Signature/or thumb impression of the subscriber to Sign
                    </span> */}
                  
                </td>
              </h2>
            </div>

            <div className="border px-4 mt-20 border-gray-600" />

            <div className="px-4 border-green-700 py-4">
              <h1 className="text-md  font-semibold mb-6 text-center">
                CERTIFICATE BY EMPLOYER
              </h1>
              <h1 className="text-sm py-2 font-normal text-center">
                Certified that the above declaration and nomination has been
                signed / thumb impressed before me by Shri / Smt./ Miss ___ ___
                employed in my establishment after he/she has read the entries /
                the entries have been read over to him/her by me and got
                confirmed by him/her.
              </h1>
            </div>

            <div className="px-4 flex justify-between gap-5 border-green-700 py-8">
              <h2 className="">Date: </h2>

              <h2 className="text-sm  font-normal text-start">
                <td className="sign px-2 py-1">
                  <span className="sign px-2 py-1">
                    {" "}
                    Signature of the employer or other authorised officer of the
                    establishment
                  </span>
                </td>
              </h2>
            </div>

            {/* Sign  */}

            <div className=" flex justify-between px-4 py-8">
              <div>
                <h2> Name & address of the factory/Established </h2>
              </div>

              <div className="px-4 gap-5 border-green-700 py-2 w-[250px]">
                <h2 className="text-sm text-start">Place : </h2>
                <h2 className="">Date : </h2>
              </div>
            </div>


            </div>
            

            <div className="modal-footer flex justify-end items-center px-4 py-2 bg-gray-100 border-t border-gray-200">
              <button
                type="button"
                className="btn-cancel py-2 px-2 bg-red-600 text-white rounded border-2 mr-2"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="py-2 px-4 bg-green-600 text-white rounded border-2 btn-save"
              >
                Save
              </button>
            </div>
          </form>

        </div>


     
      </div>

      {showSignatureModal && (
        <SignatureNewModal
          onSave={handleSaveSignature}
          onClose={closeSignatureModal}
        />
      )}

      {sucessmodel && (
        <SuccessModal msg={sucessmodel} onClose={handleclosesucessmodal} />
      )}

      {errormodel && (
        <ErrorModal msg={errormodel} onClose={handlecloseerrormodal} />
      )}
    </>
  );
};

export default EPFNomineeForm;
